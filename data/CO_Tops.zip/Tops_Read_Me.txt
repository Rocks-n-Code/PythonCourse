Tops scraped from COGCC's website (03/2018) and formated 
for import into IHS PETRA.   While spot checks have been
 made these have not been checked individually. Use as you wish!

Happy Mapping,
-Matthew W. Bauer